#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define COM_SIZE 1024
#define BUF_SIZE 1024
#define ARG_SIZE 1024
#define MAX_PATH 4096
#define T_SIZE 15

char* get_exe_name(char* path) {
    char* last_token = NULL;
    char* token = strtok(path, "/");
    while (token != NULL) {
        last_token = token;
        token = strtok(NULL, "/");
    }
    return last_token;
}

typedef struct {
    char timestamp[13];
    size_t size;
} FileData;

void get_file_data(const char* filename, FileData** data, size_t* count) {
    // Open the current directory
    DIR* dir = opendir(".");
    if (dir == NULL) {
        perror("Error opening directory");
        exit(EXIT_FAILURE);
    }
    
    *data = NULL;
    *count = 0;
    
    // Loop through all files in the directory
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, filename, strlen(filename)) == 0) {
	    //"_"제거
            char* timestamp_ptr = strstr(entry->d_name, "_");
            if (timestamp_ptr == NULL) {
                fprintf(stderr, "Error: Invalid filename format: %s\n", entry->d_name);
                exit(EXIT_FAILURE);
            }
            char timestamp[13];
            strncpy(timestamp, timestamp_ptr + 1, sizeof(timestamp) - 1);
            timestamp[12] = '\0';
            
            FILE* file = fopen(entry->d_name, "rb");
            if (file == NULL) {
                perror("Error opening file");
                exit(EXIT_FAILURE);
            }
            fseek(file, 0, SEEK_END);
            size_t size = ftell(file);
            fclose(file);
            
            *data = realloc(*data, (*count + 1) * sizeof(FileData));
            if (*data == NULL) {
                perror("Error allocating memory");
                exit(EXIT_FAILURE);
            }
            strncpy((*data)[*count].timestamp, timestamp, sizeof((*data)[*count].timestamp) - 1);
            (*data)[*count].size = size;
            (*count)++;
        }
    }
    
    closedir(dir);
}




//절대경로에서 디렉토리가 아닐 경우만 문자열 제거
char *remove_filename(char *path) {
    struct stat path_stat;
    int err = stat(path, &path_stat);
    if (S_ISDIR(path_stat.st_mode)) {
        //디렉토리인 경우) 원본 문자열을 그대로 반환
        return path;
    }

    // 파일인 경우 파일 이름 제거
    else{
    char *last_slash = strrchr(path, '/');
    if (last_slash != NULL) {
        *last_slash = '\0';
    } else {
        // '/'가 없는 경우
        path[0] = '\0';
    }
    }
    return path;
}

//d 옵션 구현 func
void d_func(char* src_dir, char* dst_dir){
    //scandir 을 위한 dirent struct 생성
    struct dirent** namelist;
    int n = scandir(src_dir, &namelist, NULL, alphasort);//n은 파일의 갯수
    //scandir 에러 처리
    if (n < 0) {
	fprintf(stderr, "scandir error for %s\n", src_dir);
        exit(1);
    }

    //파일의 갯수만큼 탐색 진행
    for (int i = 0; i < n; i++) {
        char* name = namelist[i]->d_name;
        char src_path[strlen(src_dir) + strlen(name) + 2];
        snprintf(src_path, sizeof(src_path), "%s/%s", src_dir, name);

	//파일의 stat 확인
        struct stat st;
        if (stat(src_path, &st) == -1) {
	    fprintf(stderr, "stat error for %s\n",src_path);
            exit(1);
        }

	//일반 파일의 경우
        if (S_ISREG(st.st_mode)) {
            char dst_path[strlen(dst_dir) + strlen(name) + 2];
            snprintf(dst_path, sizeof(dst_path), "%s/%s", dst_dir, name);
	    time_t now = time(NULL);
	    struct tm *t = localtime(&now);
	    char buf[T_SIZE + 2];
	    strftime(buf, T_SIZE, "_%y%m%d%H%M%S", t);
	    printf("\"%s%s\" backuped\n", src_path, buf);

	    //원래는 해시값이 다를 경우만 추가하는 조건문을 포함해야함
	    int fd1, fd2;
	    if ((fd1 = open(src_path,O_RDONLY)) < 0) {
		    fprintf(stderr, "open error for %sn", src_path);
		    exit(1);
	    }
	    strcat(dst_path,buf);
	    if ((fd2 = open(dst_path, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0) {
		    fprintf(stderr, "open error for %s\n",dst_path);
		    exit(1);
	    }
	    char p_buf[BUF_SIZE];
	    ssize_t length;
	    while ((length = read(fd1,p_buf,BUF_SIZE)) > 0) {
		    write(fd2,p_buf,length);
	    }
	    close(fd1);
	    close(fd2);
	//디렉토리의 경우
        } else if (S_ISDIR(st.st_mode)) {
            char dst_path[strlen(dst_dir) + strlen(name) + 2];
            snprintf(dst_path, sizeof(dst_path), "%s/%s", dst_dir, name);
	    //비어있는 디렉토리는 다시 삭제
	    if (n == 2) {
		    rmdir(dst_dir);
	    }
	    //기본 이동 디렉토리는 제외하고 처리
            if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) {
                continue;
            }
	    if (mkdir(dst_path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1) {
	//	fprintf(stderr, "%s is already exists\n",dst_path);
          //      exit(1);
            }
	    //재귀적으로 d 함수 호출
            d_func(src_path, dst_path);
        }
        free(namelist[i]);
    }
    free(namelist);
}

//d 옵션 구현 func
void d_func2(char* src_dir, char* dst_dir){
    //scandir 을 위한 dirent struct 생성
    struct dirent** namelist;
    int n = scandir(src_dir, &namelist, NULL, alphasort);//n은 파일의 갯수
    //scandir 에러 처리
    if (n < 0) {
        fprintf(stderr, "scandir error for %s\n", src_dir);
        exit(1);
    }

    //파일의 갯수만큼 탐색 진행
    for (int i = 0; i < n; i++) {
        char* name = namelist[i]->d_name;
        char src_path[strlen(src_dir) + strlen(name) + 2];
        snprintf(src_path, sizeof(src_path), "%s/%s", src_dir, name);

        //파일의 stat 확인
        struct stat st;
        if (stat(src_path, &st) == -1) {
            fprintf(stderr, "stat error for %s\n",src_path);
            exit(1);
        }

        //일반 파일의 경우
        if (S_ISREG(st.st_mode)) {

	    char *underscore = strrchr(name, '_');
    	    if (underscore != NULL) {
        	*underscore = '\0';
    	    }
	    FileData* data;
	    size_t count;
	    //printf("src : %s\n", src_path);
	    char tmp_path[MAX_PATH];
	    char tmp2_path[MAX_PATH];
	    strcpy(tmp_path, src_path);
	    char* re_path;

	    char *underscore1 = strrchr(tmp_path, '_');
    	    if (underscore1 != NULL) {
        	*underscore1 = '\0';
    	    }
	    strcpy(tmp2_path,tmp_path);
	    re_path = remove_filename(tmp_path);

	    //printf("tmp : %s\n",tmp_path);
	    chdir(re_path);

	    char* F_name = get_exe_name(tmp2_path);
	    //printf("fname : %s\n", F_name);
	    get_file_data(F_name,&data,&count);

	    char dst_path[strlen(dst_dir) + strlen(name) + 2];
	    snprintf(dst_path, sizeof(dst_path), "%s/%s", dst_dir, name);

	    if (count > 1) {
		printf("backup file list of \"%s\"\n0. exit\n", dst_path);
	    for(size_t i = 0; i < count; i++) {
		printf("%ld. %s    %zubytes\n", i + 1, data[i].timestamp, data[i].size);
	    }
	    printf("Choose file to recover\n>> ");
	    int idx;
	    scanf("%d",&idx);
	    }

	    
	    free(data);

            printf("\"%s\" backup recover to %s\n\n", src_path, dst_path);

            //원래는 해시값이 다를 경우만 추가하는 조건문을 포함해야함
            int fd1, fd2;
            if ((fd1 = open(src_path,O_RDONLY)) < 0) {
                    fprintf(stderr, "open error for %sn", src_path);
                    exit(1);
            }
            if ((fd2 = open(dst_path, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0) {
                    fprintf(stderr, "open error for %s\n",dst_path);
                    exit(1);
            }
            char p_buf[BUF_SIZE];
            ssize_t length;
            while ((length = read(fd1,p_buf,BUF_SIZE)) > 0) {
                    write(fd2,p_buf,length);
            }
            close(fd1);
            close(fd2);
        //디렉토리의 경우
        } else if (S_ISDIR(st.st_mode)) {
            char dst_path[strlen(dst_dir) + strlen(name) + 2];
            snprintf(dst_path, sizeof(dst_path), "%s/%s", dst_dir, name);
            //비어있는 디렉토리는 다시 삭제
            if (n == 2) {
                    rmdir(dst_dir);
            }
            //기본 이동 디렉토리는 제외하고 처리
            if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) {
                continue;
            }
            if (mkdir(dst_path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1) {
                //fprintf(stderr, "%s is already exists\n",dst_path);
                //exit(1);
            }
            //재귀적으로 d 함수 호출
            d_func2(src_path, dst_path);
        }
        free(namelist[i]);
    }
    free(namelist);
}


void cus_add(char* argv[])
{
	//Change path
	char path[MAX_PATH];
	realpath(argv[1],path);
	//printf("real path : %s\n", path);
	char backup_path[100] = "/home/brain/backup/";

	int i = 0;
	while (argv[i] != NULL) {
		//printf("%s\n",argv[i]);
		i++;
	}

	//add 하나만 입력 받을 시 Usage 출력
	if (i == 1) {
		fprintf(stderr, "Usage : add <FILENAME> [OPTION]\n -d :add directory recursive\n");
		exit(1);
	}

	//-d옵션 구현
	else if (i == 3) {
		if (strcmp(argv[2],"-d") != 0){
			fprintf(stderr, "Usage : add <FILENAME> [OPTION]\n -d :add directory recursive\n");
			exit(1);
		}
		d_func(path,backup_path);
		exit(0);
	}
	
	if (i == 2) {
	//path length over error
	if (strlen(argv[1]) > MAX_PATH) {
		fprintf(stderr, "Length over error for %s\n", argv[1]);
		exit(1);
	}

	//access error
	if (access(argv[1], R_OK) < 0) {
		fprintf(stderr, "\"%s\" can't be backuped\n", argv[1]);
		exit(1);
	}

	//Path에 backup dir 존재할 시 에러 처리
	char *ptr;
	ptr = strstr(path, "backup");
	if (ptr != NULL) {
		fprintf(stderr, "\"%s\" can't be backuped\n",argv[1]);
		exit(1);
	}

	struct stat st;
	//No backup file error or No file in dir
	if (stat(argv[1], &st) < 0){
		fprintf(stderr,"Usage : add <FILENAME> [OPTION]\n -d : add directory recursive\n");
		exit(1);
	}	
	//no dir or regular file
	if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) {
		fprintf(stderr, "<%s> error : not a dir or regular file\n", argv[1]);
		exit(1);
	}

	//마지막 / 기준으로 분리하고 백업 경로 지정
	char* F_name = get_exe_name(argv[1]);
	strcat(backup_path, F_name);

	//Dir 백업 시도시 에러처리
	if (S_ISDIR(st.st_mode)){
		fprintf(stderr, "\"%s\" is a directory file\n", path);
		exit(1);
	}

	int fd1, fd2;
	if ((fd1 = open(path, O_RDONLY)) < 0) {//Open error argv[1]
		fprintf(stderr, "%s open error\n",argv[1]);
		exit(1);
	}

	time_t now = time(NULL);
	struct tm *t = localtime(&now);
	char p_buf[T_SIZE + 2];
	strftime(p_buf, T_SIZE, "_%y%m%d%H%M%S", t);
	
	strcat(backup_path,p_buf);
	//printf("%s\n",backup_path);	
	//Creat error in backup dir
	if ((fd2 = open(backup_path, O_WRONLY | O_CREAT | O_TRUNC , 0644)) < 0) {
		fprintf(stderr, "%s open error in PATH : %s\n",argv[1], backup_path);
		exit(1);
	}
	
	printf("\"%s\" backuped\n", backup_path);
	// 백업시 현재 시간을 출력

	char buf[BUF_SIZE];
	ssize_t length;
	while ((length = read(fd1, buf, BUF_SIZE)) > 0) {
		write(fd2, buf, length);
	}

	close(fd1);
	close(fd2);
	}
	exit(0);
		
}

void cus_remove() 
{
	printf("remove function called\n");
}

void cus_recover(char* argv[]) 
{
    int i = 0;
    while(argv[i] != NULL) {
	//printf("%s\n",argv[i]);
	i++;
    }
    if (i == 1) {
	fprintf(stderr,"Usage :recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	exit(1);
    }
    

    if (i == 2) {
	char path[MAX_PATH];
	realpath(argv[1], path);
	//printf("real path : %s\n",path);
	char src_path[MAX_PATH] = "/home/brain/backup/";
    
	strcat(src_path,argv[1]);
	char tmp_path[MAX_PATH];
	strcpy(tmp_path,src_path);

	char* rec_path;
	rec_path = remove_filename(tmp_path);
	strcat(rec_path, "/");
	//printf("src_path : %s\n", src_path);
	//printf("tmp_path : %s\n", tmp_path);
	//printf("regular removed backup path : %s\n\n", rec_path);
	
	char* F_name = get_exe_name(argv[1]);

	struct stat st;
	if (stat(rec_path, &st) < 0) {
	    fprintf(stderr,"Usage :recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}

	struct dirent** namelist;
	int n = scandir(rec_path, &namelist, NULL, alphasort);
	if (n < 0) {
	    fprintf(stderr, "scandir error\n");
	    exit(1);
	}

	//파일 크기 문자열을 위한 동적 할당
	int cnt = 0;
	int *size = NULL;
	char **suffix = NULL;

	for (int i = 0; i < n; i++) {
	    if (strstr(namelist[i]->d_name, F_name) != NULL) {
		//recover 파일경로 지정
		char recover_path[MAX_PATH];
		strcpy(recover_path,rec_path);
		strcat(recover_path,namelist[i]->d_name);
		//파일 이름 길이와 이름 배열의 동적할당
		cnt++;
		size = (int*)realloc(size, cnt * sizeof(int));
		suffix = (char**)realloc(suffix, cnt * sizeof(char*));

		//파일 크기 저장
		if (stat(recover_path, &st) == 0) {
		    size[cnt-1] = st.st_size;
		}

		//argv[1]_ 뒤 문자열 저장
		char *suf_start = strstr(namelist[i]->d_name, F_name) + strlen(F_name) + 1;
		int suf_len = strlen(suf_start);
		suffix[cnt-1] = (char*)malloc((suf_len+1) * sizeof(char));
		strcpy(suffix[cnt-1],suf_start);
	    }
	}

	if (cnt == 0) {
	    fprintf(stderr,"Usage :recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}
	else {
	    printf("backup file list of \"%s\"\n", path);
	    printf("0. exit\n");
	    for (int i = 0; i < cnt; i++) {
		printf("%d. %s %dbytes\n", i+1, suffix[i], size[i]);
	    }
	    int idx_num;
	    printf("Choose file to recover\n>>");
	    scanf("%d", &idx_num);
	    strcat(rec_path,F_name);
	    strcat(rec_path,"_");
	    strcat(rec_path,suffix[idx_num-1]);

	    struct stat p_st;
	    if (stat(path, &p_st) < 0) {
		printf("\"%s\" backup file recover\n", rec_path);
	    }
	    else {
		printf("\"%s\" backup recover to \"%s\"\n",rec_path, path);
	    }

	    //백업파일 복구
	    int fd1, fd2;
	    if ((fd1 = open(rec_path, O_RDONLY)) < 0) {
		fprintf(stderr, "open error for %s\n",rec_path);
		exit(1);
	    }
	    if ((fd2 = open(path, O_WRONLY | O_CREAT | O_TRUNC,0644)) < 0) {
		fprintf(stderr, "open error for %s\n",path);
		exit(1);
	    }
	    char buf[BUF_SIZE];
	    ssize_t length;
	    while ((length = read(fd1,buf,BUF_SIZE)) > 0) {
		write(fd2,buf,length);
	    }
	    //파일 닫기
	    close(fd1);
	    close(fd2);

	    //메모리 해제
	    for (int i = 0; i < cnt; i++) {
		free(suffix[i]);
	    }

	    free(namelist[i]);
	    free(namelist);
	}

    }

    if (i == 3) {
	if (strcmp(argv[2], "-d") == 0) {

	    char path[MAX_PATH] = "/home/brain/P1/";
	    char src_path[MAX_PATH] = "/home/brain/backup/";

	    d_func2(src_path,path); 
	    
	}
	else {
	    fprintf(stderr, "Usage : recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}

    }

    if (i == 4) {
	if (strcmp(argv[2], "-n") == 0) {
//	    printf("n func called\n");
	char path[MAX_PATH];
	realpath(argv[1], path);
	//printf("real path : %s\n",path);
	char src_path[MAX_PATH] = "/home/brain/backup/";
    
	strcat(src_path,argv[1]);
	char tmp_path[MAX_PATH];
	strcpy(tmp_path,src_path);

	char* rec_path;
	rec_path = remove_filename(tmp_path);
	strcat(rec_path, "/");
	//printf("src_path : %s\n", src_path);
	//printf("tmp_path : %s\n", tmp_path);
	//printf("regular removed backup path : %s\n\n", rec_path);
	
	char* F_name = get_exe_name(argv[1]);

	struct stat st;
	if (stat(rec_path, &st) < 0) {
	    fprintf(stderr,"Usage :recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}

	struct dirent** namelist;
	int n = scandir(rec_path, &namelist, NULL, alphasort);
	if (n < 0) {
	    fprintf(stderr, "scandir error\n");
	    exit(1);
	}

	//파일 크기 문자열을 위한 동적 할당
	int cnt = 0;
	int *size = NULL;
	char **suffix = NULL;

	for (int i = 0; i < n; i++) {
	    if (strstr(namelist[i]->d_name, F_name) != NULL) {
		//recover 파일경로 지정
		char recover_path[MAX_PATH];
		strcpy(recover_path,rec_path);
		strcat(recover_path,namelist[i]->d_name);
		//파일 이름 길이와 이름 배열의 동적할당
		cnt++;
		size = (int*)realloc(size, cnt * sizeof(int));
		suffix = (char**)realloc(suffix, cnt * sizeof(char*));

		//파일 크기 저장
		if (stat(recover_path, &st) == 0) {
		    size[cnt-1] = st.st_size;
		}

		//argv[1]_ 뒤 문자열 저장
		char *suf_start = strstr(namelist[i]->d_name, F_name) + strlen(F_name) + 1;
		int suf_len = strlen(suf_start);
		suffix[cnt-1] = (char*)malloc((suf_len+1) * sizeof(char));
		strcpy(suffix[cnt-1],suf_start);
	    }
	}

	if (cnt == 0) {
	    fprintf(stderr,"Usage :recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}
	else {
	    printf("backup file list of \"%s\"\n", path);
	    printf("0. exit\n");
	    for (int i = 0; i < cnt; i++) {
		printf("%d. %s %dbytes\n", i+1, suffix[i], size[i]);
	    }
	    int idx_num;
	    printf("Choose file to recover\n>>");
	    scanf("%d", &idx_num);
	    strcat(rec_path,F_name);
	    strcat(rec_path,"_");
	    strcat(rec_path,suffix[idx_num-1]);

	    struct stat p_st;
	    if (stat(path, &p_st) < 0) {
		printf("\"%s\" backup file recover\n", rec_path);
	    }
	    else {
		char n_path[MAX_PATH];
		realpath(argv[3], n_path);
		printf("\"%s\" backup recover to \"%s\"\n",rec_path, n_path);
	    }

	    //백업파일 복구
	    int fd1, fd2;
	    if ((fd1 = open(rec_path, O_RDONLY)) < 0) {
		fprintf(stderr, "open error for %s\n",rec_path);
		exit(1);
	    }
	    if ((fd2 = open(argv[3], O_WRONLY | O_CREAT | O_TRUNC,0644)) < 0) {
		fprintf(stderr, "open error for %s\n",path);
		exit(1);
	    }
	    char buf[BUF_SIZE];
	    ssize_t length;
	    while ((length = read(fd1,buf,BUF_SIZE)) > 0) {
		write(fd2,buf,length);
	    }
	    //파일 닫기
	    close(fd1);
	    close(fd2);

	    //메모리 해제
	    for (int i = 0; i < cnt; i++) {
		free(suffix[i]);
	    }

	    free(namelist[i]);
	    free(namelist);
	}

	}
	else {
	    fprintf(stderr, "Usage : recover <FILENAME> [OPTION]\n -d : recover directory recursive\n -n <NEWNAME> : recover file with new name\n");
	    exit(1);
	}
    }

    if (i == 5) {
	printf("d, n func called\n");
    }

}

void cus_ls() 
{
	char *args[] = {"ls", NULL};
	execvp(args[0], args);
	exit(0);
}

void cus_vi() 
{
	char *args[] = {"vi", NULL};
	execvp(args[0], args);
	exit(0);
}

void cus_vim() 
{
	char* args[] = {"vim",NULL};
	execvp(args[0], args);
	exit(0);
}

void cus_help() 
{	//call help func by exec() ./help
	execl("/bin/sh","sh","-c","./help",NULL);
	perror("exec error\n");
}

//struc declare 
typedef struct node 
{
	//variable for input command function call 
	char* command;
	void (*func_ptr)();
	struct node* next;//linked list variable for next node
}Node;

//for add nodes in current linked list
Node* add_node(Node* head, char* command, void (*func_ptr)()) 
{
	Node* new_node = malloc(sizeof(Node));//make space for new mode
	new_node->command = command;
	new_node->func_ptr = func_ptr;
	new_node->next = head;
	return new_node;
}

//find command in linked list
void exe_command(Node* head, char* command) 
{
	Node* curr_node = head;

	char* token = strtok(command, " ");
	while (curr_node != NULL) 
	{
		if (strcmp(curr_node->command,token) == 0) 
		{
			//command in linked list 
			//call functions in child process
			pid_t pid = fork();
			if (pid == 0) {
				char* args[ARG_SIZE];
				args[0] = curr_node->command;
				int i = 1;
				while ((token = strtok(NULL, " ")) != NULL) {
					args[i++] = token;
				}
				args[i] = NULL;
				curr_node->func_ptr(args);
				exit(0);
			}
			else {
				int status;
				waitpid(pid,&status,0);
				return;
			}
		}
		curr_node = curr_node->next;
	}
	if (strcmp(command, "exit") == 0)
		exit(0);
	else {
		pid_t pid = fork();
		if (pid == 0) {
			cus_help();
			exit(0);
		}
		else{
			int status;
			waitpid(pid,&status,0);
		}
	}
}


int create_dir(const char * dir_path)
{
	struct stat stbuf;

	//backup dir 없을 시 /home/brain/ 에 backup dir 생성	
	if (stat(dir_path, &stbuf) == -1)
	{
		if(mkdir(dir_path, 0777) < 0)
		{
			fprintf(stderr,"디렉토리 생성 에러\n");
			exit(1);
		}
		else
			printf("디렉토리 생성\n");
	}

	return 0;
}


int main(int argc, char* argv[])
{
	//check factors and it's num 
	if (argc != 2 || (strcmp(argv[1],"md5") && strcmp(argv[1], "sha1"))){
		fprintf(stderr, "Usage: ssu_backup < md5 | sha1 >\n");
		exit(1);
	}
	
	//백업 디렉토리 없을 시 생성
	const char *dir_path = "/home/brain/backup";
	create_dir(dir_path);	
	
	//add all functions in linked list
	Node* head = NULL;
	head = add_node(head, "add", cus_add);
	head = add_node(head, "help", cus_help);
	head = add_node(head, "recover", cus_recover);
	head = add_node(head, "remove", cus_remove);
	head = add_node(head, "vi", cus_vi);
	head = add_node(head, "vim", cus_vim);
	head = add_node(head, "ls", cus_ls);

	char command[COM_SIZE];
	while(1) 
	{
		printf("20180622> ");// 내장 명령어 입력 대기
		fgets(command, COM_SIZE, stdin);
		command[strlen(command)-1] = '\0';
		if (strlen(command) == 0) {continue;}
		else{exe_command(head, command);}
	}

	return 0;		
}
