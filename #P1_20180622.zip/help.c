#include <stdio.h>
#include <stdlib.h>

//help.c
int main(void){
	printf("Usage:\n > add <FILENAME> [OPTION]\n  -d : add directory recursive\n");
	printf(" > remove <FILENMAE> [OPTION]  \n ");
	printf("-a : remove all file(recursive)\n -c : clear backup directory\n ");
	printf("> recover <FILENAME> [OPTION]\n  -d recover directory recursive\n  ");
	printf("-n [NEWNAME] : recover file with newname\n ");
	printf("> ls\n > vi\n > vim\n > help\n > exit\n");
}
